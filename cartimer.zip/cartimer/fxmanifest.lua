fx_version 'cerulean'
game 'gta5'

lua54 'yes'

description 'Mulmers speed mesuring script'

server_scripts {
	'config.lua',
    '**/s_*.lua',
}

client_scripts {
	'config.lua',
    '**/c_*.lua',
}